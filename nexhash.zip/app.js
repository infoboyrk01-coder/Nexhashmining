// Telegram WebApp Initialization
const tg = window.Telegram.WebApp;

// Screen fully open (Expand) karein
tg.expand();

// Application Theme Sync
tg.enableClosingConfirmation();

// Telegram User Details Fetching
if (tg.initDataUnsafe && tg.initDataUnsafe.user) {
    const user = tg.initDataUnsafe.user;
    
    // User name set karein
    const fullName = user.first_name + (user.last_name ? " " + user.last_name : "");
    document.getElementById('username').innerText = fullName;
    
    // User ID set karein
    document.getElementById('user-id').innerText = user.id;
} else {
    // Local testing ke liye (jab browser me kholte hain)
    document.getElementById('username').innerText = "Nexhash User";
    document.getElementById('user-id').innerText = "987654321";
}

// Navigation Tabs Switching (Simple Interaction)
const navItems = document.querySelectorAll('.nav-item');

navItems.forEach(item => {
    item.addEventListener('click', () => {
        navItems.forEach(i => i.classList.remove('active'));
        item.classList.add('active');
    });
});
